import { CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ThankYou() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 sm:p-12 text-center border border-gray-100">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>

          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            ご購入ありがとうございます
          </h1>

          <p className="text-lg text-gray-600 mb-8 leading-relaxed">
            お支払いが完了いたしました。
            <br />
            担当者より追ってご連絡させていただきます。
          </p>

          <div className="bg-blue-50 rounded-xl p-6 mb-8 text-left border border-blue-100">
            <h2 className="font-bold text-gray-900 mb-3">今後の流れ</h2>
            <ol className="space-y-3 text-gray-600">
              <li className="flex items-start">
                <span className="font-bold text-blue-600 mr-3">1.</span>
                <span>ご登録いただいたメールアドレスに確認メールをお送りします</span>
              </li>
              <li className="flex items-start">
                <span className="font-bold text-blue-600 mr-3">2.</span>
                <span>担当者より1営業日以内にご連絡させていただきます</span>
              </li>
              <li className="flex items-start">
                <span className="font-bold text-blue-600 mr-3">3.</span>
                <span>詳細のヒアリング後、制作を開始いたします</span>
              </li>
            </ol>
          </div>

          <div className="space-y-4">
            <Link
              to="/"
              className="block w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition-colors"
            >
              トップページに戻る
            </Link>
            <Link
              to="/products"
              className="block w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-bold hover:bg-gray-200 transition-colors"
            >
              他の商品を見る
            </Link>
          </div>

          <p className="text-sm text-gray-500 mt-8">
            ご不明な点やお急ぎの場合は、確認メールに記載の連絡先までお問い合わせください。
          </p>
        </div>
      </div>
    </div>
  );
}
